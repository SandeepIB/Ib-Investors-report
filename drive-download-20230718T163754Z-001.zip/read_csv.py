# use below CLI command to generate output
# python read_csv.py sheet1.csv 1
# python read_csv.py sheet2.csv 2
# python read_csv.py sheet3.csv 3
# python read_csv.py sheet4.csv 4
import csv
import argparse
import sys

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('sheet_name', type=str, help='Name of the sheet')
    parser.add_argument('sheet_number', type=int, nargs='?', help='Number representing the sheet')
    args = parser.parse_args()

    if args.sheet_name is None:
        print("Please provide a sheet name and number as a command-line argument. (Ex: python app.py sheet.csv 1)")
        sys.exit(1)  # Terminate the script with exit code 1 for an error condition

    if args.sheet_number is None:
        print("Please provide a sheet number as a command-line argument. (Ex: python app.py sheet.csv 1)")
        sys.exit(1)  # Terminate the script with exit code 1 for an error condition

    sheet_number = args.sheet_number
    csvFilePath  = args.sheet_name

columnIndex = 2  # Index of the column you want to extract (zero-based index)
def getCSVColumn(csvFile, columnIndex):
    with open(csvFile, 'r') as file:
        # Skip the first 14 rows
        for _ in range(14):
            next(file)

        # Initialize a list to store the column data
        columnData = []

        # Read each line of the CSV file
        reader = csv.reader(file)
        for rindex, row in enumerate(reader):
            # Check if the column index is within the row bounds
            if len(row) > columnIndex:
                # Store the value of the column in the list
                columnData.append(row[columnIndex])

                if sheet_number == 3:
                    if int(rindex) >= 98:
                        break

        # Return the extracted column data
        return columnData

result_e = []
result_f = []

if sheet_number == 1 or sheet_number == 3 or sheet_number == 4:
    result_d = getCSVColumn(csvFilePath, 3)
elif sheet_number == 2:
    result_e = getCSVColumn(csvFilePath, 4)
    result_f = getCSVColumn(csvFilePath, 5)


result_c = getCSVColumn(csvFilePath, 2)
result_i = getCSVColumn(csvFilePath, 8)
result_j = getCSVColumn(csvFilePath, 9)
result_k = getCSVColumn(csvFilePath, 10)
result_l = getCSVColumn(csvFilePath, 11)
result_m = getCSVColumn(csvFilePath, 12)
result_n = getCSVColumn(csvFilePath, 13)

result_o = getCSVColumn(csvFilePath, 14)

mergedArray = []
marray=[]
# Iterate over the arrays and merge the elements

if sheet_number == 1 or sheet_number == 3:
    for index, value in enumerate(result_c):
        if index < len(result_d):
            mergedArray.append(value + ' ' + result_d[index])
        else:
            mergedArray.append(value)

elif sheet_number == 2:
    for index, value in enumerate(result_c):
        if index < len(result_e):
            mergedArray.append(value + ' ' + result_e[index])
        else:
            mergedArray.append(value)

    for index, value in enumerate(mergedArray):
        if index < len(result_f):
            marray.append(value + ' ' + result_f[index])
        else:
            marray.append(value)

elif sheet_number == 4:
    mergedArray = result_c

final_arr = []

for mindex, mvalue in enumerate(mergedArray):
    if sheet_number == 1 or sheet_number == 3:
        columns = {
            'i': {'result': result_i, 'header': result_i[0]},
            'j': {'result': result_j, 'header': result_i[0] if result_j[0] == '' else ''},
            'k': {'result': result_k, 'header': result_i[0] if result_k[0] == '' else result_k[0]},
            'l': {'result': result_l, 'header': result_i[0] if result_l[0] == '' else result_l[0]},
            'm': {'result': result_m, 'header': result_i[0] if result_m[0] == '' else result_m[0]},
            'n': {'result': result_n, 'header': result_i[0] if result_n[0] == '' else result_n[0]},
            'o': {'result': result_o, 'header': result_i[0] if result_o[0] == '' else result_o[0]}
        }
    elif sheet_number == 2 or sheet_number == 4:
        columns = {
            'i': {'result': result_i, 'header': result_i[0]},
            'j': {'result': result_j, 'header': result_i[0] if result_j[0] == '' else ''},
        }

    for column, data in columns.items():
        result = data['result']
        header = data['header']
        trimed_spaces = result[mindex].replace(' ', '')
        if mvalue != ' ' and trimed_spaces != '' and trimed_spaces != '-':
            value = f"{mvalue} {header} {result[1]} {result[mindex]} cr."
            final_arr.append(value)

print(final_arr)
outputText = '\n'.join(final_arr)

# Save the output to a text file
file = f"output{sheet_number}.txt"
with open(file, 'w') as output_file:
    output_file.write(outputText)

print(f"Output saved to {file}")